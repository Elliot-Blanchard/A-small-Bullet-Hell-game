import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Trails extends PApplet {

int fond = color(0, 30, 50);
ArrayList<vaisseau> Vaisseaux  = new ArrayList<vaisseau>();
ArrayList<projectile> Tirs  = new ArrayList<projectile>();
int nombreVaisseaux = 10;
int Niveau = 1;
boolean mousePause = false;
boolean pause = false;
boolean godMode = false;
int delayCounter = 0;
boolean timer = false;
boolean lvUp = false;

public void setup() {
  frameRate(60);
  
  background(fond);
  genVaisseaux();
}



public void genVaisseaux() {
  if (Vaisseaux.size() == 0) {
    for (int i = 0; i < nombreVaisseaux; i++) {
      if (i == 0) {
        Vaisseaux.add(new vaisseau(width, height, 10, color(20, 180, 180), 20, true));
      } else {
        Vaisseaux.add(new vaisseau(100, 100, random(5, 15), color(random(120, 255), random(0, 20), random(0, 20)), random(15, 30), false));
      }
    }
  } else {
    for (int i = 0; i < nombreVaisseaux - 1; i++) {
      Vaisseaux.add(new vaisseau(100, 100, random(5, 15), color(random(120, 255), random(0, 20), random(0, 20)), random(15, 30), false));
    }
  }
}



public void draw() {
  textSize(12);
  checkMousePos();
  if (pause == false && mousePause == false) {


    background(fond);

    fill(255);

    text(Niveau, 10, 15);
    for (int i = 0; i < Vaisseaux.size(); i++) { 
      vaisseau V = Vaisseaux.get(i);
      V.update();
      for (int j = 0; j < Tirs.size(); j++) { 
        projectile P = Tirs.get(j);
        if (P.joueur != V.joueur) {
          if (sqrt(sq(V.pX - P.pX)+sq(V.pY - P.pY)) < V.r/2 + P.r/2) {
            if (V.joueur == false || godMode == false) {
              Vaisseaux.remove(i);
              Tirs.remove (j);
              j = Tirs.size() - 1;
            }
          }
        }
      }
    }
    if (Tirs.size() != 0) {
      for (int i = 0; i < Tirs.size(); i++) { 
        projectile P = Tirs.get(i);
        P.update();
        if (P.pY <= 0 || P.pY >= height) {
          Tirs.remove(i);
        }
      }
    }
    if (Vaisseaux.size() == 1 && Vaisseaux.get(0).joueur == true) {

      if (lvUp == false) {
        Niveau ++;
        nombreVaisseaux += 10;
        lvUp = true;
      }
      timer = delai(300);
      if (timer == true) {
        genVaisseaux();
        lvUp = false;
      }
    }
  } else {
    fill(255);
    textSize(36);
    text("pause", width/2 - 40, height/2);
  }
}



class vaisseau {
  float cooldown = 120;
  int pX, pY;
  int ppX, ppY;
  float vM, vX, vY, r;
  int c;
  boolean joueur;
  boolean beam = false;
  float power = 0;
  int posXcible = width/2;
  int posYcible = height/4;
  vaisseau(int Xp, int Yp, float vitesseMax, int couleur, float rayon, boolean Joueur) {
    pX = Xp; 
    pY = Yp; 
    vM = vitesseMax;
    r = rayon; 
    c= couleur; 
    joueur = Joueur;
  }

  public void update() {
    if (joueur == true) {
      posXcible = mouseX;
      posYcible = mouseY;
      if (beam == true) {
        if (godMode == false) {
          power -= 2.5f;
        }
        if (power > 0) {
          beam();
        } else {
          beam = false;
        }
      } else {
        if (power < 100) {
          power += 0.5f;
        }
      }
    } else {
      cooldown -= 1;
      if (pX == posXcible && pY == posYcible) {
        float xS = random(-1, 1);
        float yS = random(-1, 1);
        posXcible += PApplet.parseInt(random(100, 400)) * xS/abs(xS);
        posYcible += PApplet.parseInt(random(100, 400)) * yS/abs(yS);
      }
      if (posXcible <= 0 || posXcible >= width) {
        posXcible = width/2;
      }
      if (posYcible <= 0 || posYcible >= 3*height/4) {
        posYcible = height/4;
      }
      for (int i = 0; i < Vaisseaux.size(); i++) { 
        vaisseau V = Vaisseaux.get(i);
        if ( V.joueur == true && V.pX >= pX - V.r/2 && V.pX <= pX + V.r/2 && cooldown <= 0) {
          tir();
          cooldown = 60 * (PApplet.parseFloat(Vaisseaux.size())/PApplet.parseFloat(nombreVaisseaux));
        }
      }
    }

    if (sqrt(sq(pX - posXcible) + sq(pY - posYcible)) > vM) {
      ppX = pX;
      ppY = pY;
      pX -= vM * cos(atan2(pY - posYcible, pX - posXcible));
      pY -= vM * sin(atan2(pY - posYcible, pX - posXcible));
      vX = pX - ppX;
      vY = pY - ppY;
    } else {
      vX = posXcible - pX;
      vY = posYcible - pY;
      pX = posXcible;
      pY = posYcible;
    }
    fill(c);
    stroke(c);
    ellipse(pX, pY, r, r);
    if (joueur == true) {
      fill(0);
      rect(pX - r/2, pY + r, r, 5);
      fill(c);
      rect(pX - r/2, pY + r, power/100 * r, 5);
    }
  }

  public void tir() {
    float vitesseTir = 10;
    if (joueur == true) {
      Tirs.add(new projectile(pX, pY, -vitesseTir, vX, c, r/3, joueur, false));
    } else {
      for (int i = 0; i < Vaisseaux.size(); i++) {
        vaisseau V = Vaisseaux.get(i);
        if ( V.joueur == true) {
          Tirs.add(new projectile(pX, pY, random(vitesseTir / 2, vitesseTir / 1.5f), V.vX * random (0, 1.5f), c, r/3, joueur, false));
        }
      }
    }
  }

  public void beam() {
    Tirs.add(new projectile(pX, pY - 5, -10, vX / 2, c, 2, joueur, true));
    Tirs.add(new projectile(pX, pY, -10, vX / 2, c, 2, joueur, true));
  }
}



class projectile {
  int pX, pY;
  float vY, vX, r;
  int c;
  boolean joueur;
  boolean beam;
  projectile(int Xp, int Yp, float vitesseY, float vitesseX, int couleur, float rayon, boolean Joueur, boolean beam) {
    pX = Xp; 
    pY = Yp; 
    vY = vitesseY;
    vX = vitesseX;
    r = rayon; 
    c= couleur; 
    joueur = Joueur;
    if (beam == true) {
    }
  }
  public void update() {
    pY += vY;
    pX += vX;
    fill(c);
    stroke(c);
    ellipse(pX, pY, r, r);
    if (beam == true) {
      line(pX, pY, pX, pY - 15);
    }
  }
}

public void checkMousePos() {
  if (mouseX < 0 || mouseX > width ||mouseY < 0 || mouseY > height) {
    mousePause = true;
  } else {
    mousePause = false;
  }
}


public boolean delai(int N) {
  boolean delai = false;
  if (delayCounter >= N) {
    delai = true;
    delayCounter = 0;
  }
  if (delayCounter <= 60 && delayCounter >= 0){
    fill(255,0,0);
    textSize(36);
    text("5", width/2, height/2);
  }
  if (delayCounter <= 120 && delayCounter >= 60){
    fill(255,0,0);
    textSize(36);
    text("4", width/2, height/2);
  }
  if (delayCounter <= 180 && delayCounter >= 120){
    fill(255,0,0);
    textSize(36);
    text("3", width/2, height/2);
  }
  if (delayCounter <= 240 && delayCounter >= 180){
    fill(255,0,0);
    textSize(36);
    text("2", width/2, height/2);
  }
  if (delayCounter <= 300 && delayCounter >= 240){
    fill(255,0,0);
    textSize(36);
    text("1", width/2, height/2);
  }
  delayCounter ++;
  return delai;
}

public void mousePressed() {
  for (int i = 0; i < Vaisseaux.size(); i++) { 
    vaisseau V = Vaisseaux.get(i);
    if (V.joueur == true) {
      V.tir();
    }
  }
}



public void keyPressed() {
  if (key == ' ') {
    if (pause == true) {
      pause = false;
    } else {
      pause = true;
    }
  }
  if (key == 'r' || key == 'R') {
    reset();
  }
  if (key == 'x' || key == 'X') {
    for (int i = 0; i < Vaisseaux.size(); i++) { 
      vaisseau V = Vaisseaux.get(i);
      if (V.joueur == true) {
        if (V.beam == false && V.power == 100) {
          V.beam = true;
        } else {
          V.beam = false;
        }
      }
    }
  }
  if (key == 'g' || key == 'G') {
    if (godMode == false) {
      godMode = true;
    } else {
      godMode = false;
    }
  }
}

public void reset() {
  int n = Vaisseaux.size();
  for (int i = 0; i < n; i++) {
    Vaisseaux.remove(0);
  }
  genVaisseaux();
}
  public void settings() {  size(1200, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Trails" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
